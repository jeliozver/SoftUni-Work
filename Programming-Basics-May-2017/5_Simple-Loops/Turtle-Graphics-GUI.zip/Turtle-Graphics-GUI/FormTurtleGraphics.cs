﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Nakov.TurtleGraphics;

namespace Turtle_Graphics_GUI
{
    public partial class FormTurtleGraphics : Form
    {
        public FormTurtleGraphics()
        {
            InitializeComponent();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            Turtle.Reset();
        }

        private void buttonHideTurtle_Click(object sender, EventArgs e)
        {
            if (Turtle.ShowTurtle)
            {
                Turtle.ShowTurtle = false;
                this.buttonHideTurtle.Text = "Show Turtle";
            }
            else
            {
                Turtle.ShowTurtle = true;
                this.buttonHideTurtle.Text = "Hide Turtle";
            }
        }

        private void buttonDraw_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.Blue;
            Turtle.Delay = 200;

            Turtle.Rotate(30);
            Turtle.Forward(200);
            Turtle.Rotate(120);
            Turtle.Forward(200);
            Turtle.Rotate(120);
            Turtle.Forward(200);

            Turtle.Rotate(-30);
            Turtle.PenUp();
            Turtle.Backward(50);
            Turtle.PenDown();
            Turtle.Backward(100);
            Turtle.PenUp();
            Turtle.Forward(150);
            Turtle.PenDown();
            Turtle.Rotate(30);
        }

        private void buttonHexagon_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.Brown;
            Turtle.Delay = 150;

            for (int i = 0; i < 6; i++)
            {
                Turtle.Rotate(60);
                Turtle.Forward(100);
            }
        }

        private void buttonStar_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.Green;
            Turtle.Delay = 150;

            for (int i = 0; i < 5; i++)
            {
                Turtle.Forward(200);
                Turtle.Rotate(144);
            }
           
        }

        private void buttonSpiral_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.Red;
            Turtle.Delay = 80;

            for (int i = 0; i < 20; i++)
            {
                Turtle.Forward(i * 10);
                Turtle.Rotate(60);
            }
        }

        private void buttonSun_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.DarkViolet;
            Turtle.Delay = 10;

            for (int i = 0; i < 36; i++)
            {
                Turtle.Backward(100);
                Turtle.Rotate(9);
                Turtle.Forward(130);
                Turtle.Rotate(200);
            }
        }

        private void buttonSpiralTriangle_Click(object sender, EventArgs e)
        {
            Turtle.PenColor = Color.DarkSalmon;
            Turtle.Delay = 10;

            for (int i = 0; i < 22; i++)
            {
                Turtle.Forward(i * 10);
                Turtle.Rotate(120);
            }
            for (int i = 0; i < 22; i++)
            {
                Turtle.Forward(i * 10);
                Turtle.Rotate(120);
            }
            for (int i = 0; i < 22; i++)
            {
                Turtle.Forward(i * 10);
                Turtle.Rotate(120);
            }
        }
    }
}
