﻿using System.Web.Mvc;

namespace WebApp_Ratings.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult DrawRating(int rating)
        {
            int fullStars = rating * 10 / 100;
            int emptyStars = (100 - rating) * 10 / 100;
            int halfStars = 10 - fullStars - emptyStars;
            string stars = "";

            for (int i = 0; i < fullStars; i++)
            {
                stars += "<img src='/images/full-star.png' />";
            }
            for (int i = 0; i < halfStars; i++)
            {
                stars += "<img src='/images/half-star.png' />";
            }
            for (int i = 0; i < emptyStars; i++)
            {
                stars += "<img src='/images/empty-star.png' />";
            }

            ViewBag.Stars = stars;
            ViewBag.Rating = rating;
            return View("Index");
        }
    }
}